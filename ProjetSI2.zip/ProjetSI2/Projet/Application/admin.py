from django.contrib import admin
from .models import (
    Employe, Service, Contrat, Salaire,
    Formation, Conge, Evaluation,
    SuivreFormation, PrendreConge, Presence, Recrutement
)

admin.site.register(Service)
admin.site.register(Contrat)
admin.site.register(Salaire)
admin.site.register(Formation)
admin.site.register(Conge)
admin.site.register(Evaluation)
admin.site.register(SuivreFormation)
admin.site.register(PrendreConge)
admin.site.register(Presence)
admin.site.register(Recrutement)

@admin.register(Employe)
class EmployeAdmin(admin.ModelAdmin):
    list_display = ('ID_Employe', 'Nom', 'Prenom', 'Date_Embauche', 'ID_Service')
    search_fields = ('Nom', 'Prenom', 'ID_Employe')
    list_filter = ('Date_Embauche', 'ID_Service')
