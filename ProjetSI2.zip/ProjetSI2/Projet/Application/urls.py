from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('employe/<int:employe_id>/', views.fiche_employe, name='fiche_employe'),
    path('employe/<int:employe_id>/ajouter_evaluation/', views.ajouter_evaluation, name='ajouter_evaluation'),
    path('rapport-evaluation/<int:employe_id>/', views.generer_rapport_evaluation, name='generer_rapport_evaluation'),
    path('tableau_de_bord/', views.tableau_de_bord, name='tableau_de_bord'),
    path('contrats/', views.liste_contrats, name='liste_contrats'),
    path('contrats/archiver/<int:contrat_id>/', views.archiver_contrat, name='archiver_contrat'),
    path('contrats/imprimer/<int:contrat_id>/', views.imprimer_contrat, name='imprimer_contrat'),
    path('contrats/archives/', views.liste_contrats_archives, name='liste_contrats_archives'),
]

