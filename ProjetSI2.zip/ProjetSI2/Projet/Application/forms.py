from django import forms
from .models import Evaluation

class EvaluationForm(forms.ModelForm):
    class Meta:
        model = Evaluation
        fields = ['Type_Evaluation', 'Note_Evaluation', 'Objectif_Atteint', 'Competence_Developpee']

from django import forms
from .models import Contrat

class ContratForm(forms.ModelForm):
    class Meta:
        model = Contrat
        fields = ['Type_Contrat', 'Date_Debut', 'Date_Fin']        



